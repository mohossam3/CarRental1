package vehicle;

public class Car extends Vehicle {

	public String bodyType;
	public String gearType;
	public int engineSize;

	
	public Car() {
		super();
	}


	/**
	 * 
	 * @param vechileNo
	 * @param make
	 * @param brand
	 * @param model
	 * @param modelYear
	 * @param available
	 * @param dailyRate
	 * @param bodyType
	 * @param gearType
	 * @param engineSize
	 */
	public Car(int vechileNo, String make, String brand, String model, int modelYear, boolean available,
			double dailyRate, Rental rental, String bodyType, String gearType, int engineSize) {
		super(vechileNo, make, brand, model, modelYear, available, dailyRate, rental);
		this.bodyType = bodyType;
		this.gearType = gearType;
		this.engineSize = engineSize;
	}
	
	
		/**
		 * getBodyType()
		 * 
		 * @return bodyType
		 */
	public String getBodyType() {
		return bodyType;
	}
	


	/**
	 * 
	 * @param bodyType
	 */
	public void setBodyType(String bodyType) {
		this.bodyType = bodyType;
	}
	/**
	 * getGearType()
	 * 
	 * @return gearType
	 */
	public String getGearType() {
		return gearType;
	}
	/**
	 * 
	 * @param gearType
	 */
	public void setGearType(String gearType) {
		this.gearType = gearType;
	}
	/**
	 * getEngineSize()
	 * 
	 * @return engineSize
	 */
	public int getEngineSize() {
		return engineSize;
	}
	/**
	 * 
	 * @param engineSize
	 */
	public void setEngineSize(int engineSize) {
		this.engineSize = engineSize;
	}
	@Override
	public String toString() {
		return "Car ["+super.toString()+"body Type: " + bodyType + ", gear Type: " + gearType + ", engine Size:" + engineSize + ", rental: "
				 + "]";
	}

}
