package vehicle;

import manager.DataManager;
import manager.RentDataManager;

public abstract class Vehicle {
	public int vechileNo;
	public String make;
	public String brand;
	public String model;
	public int modelYear;
	public boolean available = true;
	public double dailyRate;
	public Rental rental;

	/**
	 * 
	 * @param vechileNo
	 * @param make
	 * @param brand
	 * @param model
	 * @param modelYear
	 * @param available
	 * @param dailyRate
	 */

	public Vehicle(int vechileNo, String make, String brand, String model, int modelYear, boolean available,
			double dailyRate, Rental rental) {
		super();
		this.vechileNo = vechileNo;
		this.make = make;
		this.brand = brand;
		this.model = model;
		this.modelYear = modelYear;
		this.available = available;
		this.dailyRate = dailyRate;
		this.rental = rental;
	}

	public Vehicle() {
		super();
	}

	public Rental getRental() {
		return rental;
	}

	public void setRental(Rental rental) {
		this.rental = rental;
	}

	/**
	 * getVechileNo()
	 * 
	 * @return vechileNo
	 */

	public int getVechileNo() {
		return vechileNo;
	}

	/**
	 * 
	 * @param vechileNo
	 */
	public void setVechileNo(int vechileNo) {
		this.vechileNo = vechileNo;
	}

	/**
	 * isAvailable()
	 * 
	 * @return available
	 */
	public boolean isAvailable() {
		return available;
	}

	/**
	 * 
	 * @param available
	 */
	public void setAvailable(boolean available) {
		this.available = available;
	}

	/**
	 * getMake()
	 * 
	 * @return make
	 */
	public String getMake() {
		return make;
	}

	/**
	 * 
	 * @param make
	 */
	public void setMake(String make) {
		this.make = make;
	}

	/**
	 * getBrand()
	 * 
	 * @return brand
	 */
	public String getBrand() {
		return brand;
	}

	/**
	 * 
	 * @param brand
	 */
	public void setBrand(String brand) {
		this.brand = brand;
	}

	/**
	 * getModel()
	 * 
	 * @return model
	 */
	public String getModel() {
		return model;
	}

	/**
	 * 
	 * @param model
	 */
	public void setModel(String model) {
		this.model = model;
	}

	/**
	 * getModelYear()
	 * 
	 * @return modelYear
	 */
	public int getModelYear() {
		return modelYear;
	}

	/**
	 * 
	 * @param modelYear
	 */
	public void setModelYear(int modelYear) {
		this.modelYear = modelYear;
	}

	public boolean isCarAvailable(int v) {
		boolean available = true;

		for (int i = 0; i < DataManager.AllCars.size(); i++) {
			if (DataManager.AllCars.get(i).getVechileNo() != v) {
				System.out.println("Vehicle with this number isn't Avilable");
				available = false;
			}

		}
		return this.available = available;
	}

	public double getDailyRate() {
		return dailyRate;
	}

	public void setDailyRate(double dailyRate) {
		this.dailyRate = dailyRate;
	}

	public void RegisterVehicle() {

	}

	public String FindVehicle(int v) {

		String s = "";
		if (isCarAvailable(v) == true) {

			for (int j = 0; j < DataManager.AllCars.size(); j++) {
				s = DataManager.AllCars.get(j).toString();
				System.out.println(s);
			}
		}
		return s;
	}

	@Override
	public String toString() {
		return ", Vechile No: " + getVechileNo() + ",Made in: " + getMake() + ", Brand: " + getBrand() + ", Model: "
				+ getModel() + ", Model of Year: " + getModelYear() + ", Daily Rate: " + getDailyRate()+ "Rental Details"+ rental;
	}

}
