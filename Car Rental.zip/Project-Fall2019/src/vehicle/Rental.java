package vehicle;


import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

import customer.Payment;
import manager.RentDataManager;

/**
 * @project Car-Rental System - (Phase I)
 * @version 1.0
 * @class Rental
 * @author Omar Teleb
 * @QUID 201608748
 */

public class Rental {
	public LocalDate StartDate = LocalDate.now();
	public int numberOfDays;
	public  LocalDate DateOFreturn;
	public  LocalDate returnDate;
	public double latenessDeduction;
	public double damageDeduction;
	public Payment payment;
	
	


	public Rental() {

	}
	/**
	 * 
	 * @param startDate
	 * @param numberOfDays
	 * @param returnDate
	 * @param latenessDeduction
	 * @param damageDeduction
	 * @param payment
	 */


	public Rental(LocalDate startDate, int numberOfDays, LocalDate dateOFreturn, LocalDate returnDate,
			double latenessDeduction, double damageDeduction, Payment payment) {
		super();
		StartDate = startDate;
		this.numberOfDays = numberOfDays;
		DateOFreturn = dateOFreturn;
		this.returnDate = returnDate;
		this.latenessDeduction = latenessDeduction;
		this.damageDeduction = damageDeduction;
		this.payment = payment;
	}

	public LocalDate getDateOFreturn() {
		return DateOFreturn;
	}
	public void setDateOFreturn(LocalDate dateOFreturn) {
		DateOFreturn = dateOFreturn;
	}
	public Payment getPayment() {
		return payment;
	}
	public void setPayment(Payment payment) {
		this.payment = payment;
	}
	/**
	 * getStartDate()
	 * 
	 * @return StartDate
	 */
	public  LocalDate getStartDate() {
		return StartDate;
	}

	/**
	 * 
	 * @param startDate
	 */

	public void setStartDate(LocalDate startDate) {
		StartDate = startDate;
	}

	/**
	 * 
	 * @return
	 */

	public int getNumberOfDays() {
		return numberOfDays;
	}

	/**
	 * 
	 * @param numberOfDays
	 */

	public void setNumberOfDays(int numberOfDays) {
		this.numberOfDays = numberOfDays;
	}

	/**
	 * 
	 * @return
	 */

	public LocalDate getReturnDate() {
		return returnDate;
	}

	/**
	 * 
	 * @param returnDate
	 */

	public void setReturnDate(LocalDate returnDate) {
		this.returnDate = returnDate;
	}

	

	/**
	 * 
	 * @return 
	 * @return
	 */

	public double getLatenessDeduction() {
		
		return latenessDeduction;
	}

	/**
	 * 
	 * @param latenessDeduction
	 */

	public double setLatenessDeduction(double r) {
		return this.latenessDeduction = r*1.5;
		
	}

	/**
	 * 
	 * @return
	 */

	public double getDamageDeduction() {
		return damageDeduction;
	}

	/**
	 * 
	 * @param damageDeduction
	 */

	public void setDamageDeduction(double damageDeduction) {
		this.damageDeduction = damageDeduction;
	}

	/**
	 * 
	 * @return
	 */
	
	public double processReturn(double numberOfDamage, double l, Vehicle v) {
		//getReturnDate();
		calaOverdueDays();
		calcLatenessDeduction(l);
		calcDamageDeduction(numberOfDamage);
		double AllDeductionAmount= calcDamageDeduction(numberOfDamage)+calcLatenessDeduction(l);
		System.out.println("-----------------------------------");
		System.out.println("Overdue Days: " + calaOverdueDays());
		System.out.println("All Lateness Deduction: QR." + calcLatenessDeduction(l));
		System.out.println("All Damage Deduction: QR."+ calcDamageDeduction(numberOfDamage));
		System.out.println("All Deduction Amount: QR."+AllDeductionAmount );
		System.out.println("-----------------------------------");
		return AllDeductionAmount;
	}

	/**
	 * 
	 * @param OverdueDays.
	 * @return number of Overdue Days.
	 */
	public long calaOverdueDays() {
		long OverdueDays;
		LocalDate FristDate = getStartDate();
		LocalDate lastDate = getReturnDate();
		long Days = ChronoUnit.DAYS.between(FristDate, lastDate);
		if (Days > getNumberOfDays())
		OverdueDays = Days - getNumberOfDays();
		else 
			OverdueDays = 0;
		return OverdueDays;
	}
	
	public double calcLatenessDeduction(double L) {
		
		double LateDeduction = calaOverdueDays()*setLatenessDeduction(L);
		
		return LateDeduction;
		
	}
	
public double calcDamageDeduction(double numberOfDamage) {
	double calc = getDamageDeduction()*numberOfDamage ;
	
	return calc;
	}

	@Override
	public String toString() {
		return "Rental Details:\n"
				+ "--------------\nStart Date: " + StartDate + "\nRental for (" + numberOfDays+") Days" + "\nReturn Date: " + returnDate
				+ "\nIf lateness Deduction: " + latenessDeduction + "\ndamage Deduction: " + damageDeduction+"Paymetn: "+payment;
	}

}
