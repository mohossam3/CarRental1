package vehicle;

public class Bus extends Vehicle {

	public int numberOfSeats;


	public Bus() {
		super();
	}

	
	/**
	 * 
	 * @param vechileNo
	 * @param make
	 * @param brand
	 * @param model
	 * @param modelYear
	 * @param available
	 * @param dailyRate
	 * @param numberOfSeats
	 */

	public Bus(int vechileNo, String make, String brand, String model, int modelYear, boolean available,
			double dailyRate, Rental rental, int numberOfSeats) {
		super(vechileNo, make, brand, model, modelYear, available, dailyRate, rental);
		this.numberOfSeats = numberOfSeats;
	}

	/**
	 * getNumberOfSeats()
	 * 
	 * @return numberOfSeats
	 */
	public int getNumberOfSeats() {
		return numberOfSeats;
	}

	/**
	 * 
	 * @param numberOfSeats
	 */
	public void setNumberOfSeats(int numberOfSeats) {
		this.numberOfSeats = numberOfSeats;
	}

	/**
	 * isAvailable()
	 * 
	 * @return available
	 */
	public boolean isAvailable() {
		return available;
	}

	/**
	 * 
	 * @param available
	 */
	public void setAvailable(boolean available) {
		this.available = available;
	}

	@Override
	public String toString() {
		return "Bus [" + super.toString() + "numberOfSeats: " + numberOfSeats + "]";
	}

}