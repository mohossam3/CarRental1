package customer;

import vehicle.Bus;
import vehicle.Car;
import vehicle.Vehicle;

/**
 * 
 * @project Car-Rental System - (Phase I)
 * @version 1.0
 * @class Resident
 * @author Mohamed Abdelmoety
 * @QUID 201703976
 */
public class Resident extends Customer {

	public int idCard;
	public String bankName;


	/**
	 * 
	 * @param custNo
	 * @param name
	 * @param tel
	 * @param address
	 * @param nationality
	 * @param idCard
	 * @param bankName
	 */


	public Resident(int custNo, String name, int tel, String address, String nationality, Car car, Bus bus, int idCard,
			String bankName) {
		super(custNo, name, tel, address, nationality, car, bus);
		this.idCard = idCard;
		this.bankName = bankName;
	}


	public Resident(int idCard, String bankName) {
		super();
		this.idCard = idCard;
		this.bankName = bankName;
	}
	

	


	public Resident() {
		
	}

	/**
	 * getIdCard()
	 * 
	 * @return idCard
	 */
public int getIdCard() {
	return idCard;
}

	/**
	 * 
	 * @param idCard
	 */
	public void setIdCard(int idCard) {
		this.idCard = idCard;
	}

	/**
	 * getBankName()
	 * 
	 * @return bankName
	 */
	public String getBankName() {
		return bankName;
	}

	/**
	 * 
	 * @param bankName
	 */
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	@Override
	public String toString() {
		return "Resident [" + super.toString() + " , ID Card: " + idCard + " , Bank Name: " + bankName + "]";
	}

}
