package customer;

/**
 * 
 * @project Car-Rental System - (Phase I)
 * @version 1.0
 * @class Resident
 * @author Mohamed Abdelmoety
 * @QUID 201703976
 */
import java.util.Date;

import vehicle.Car;
import vehicle.Vehicle;

public class Visitor extends Customer {
	public int passportNo;
	public Date visitStart;
	public Date visitEnd;

	// public Car car;
//	public Payment payment;

	/**
	 * 
	 * @param custNo
	 * @param name
	 * @param tel
	 * @param address
	 * @param nationality
	 * @param passportNo
	 * @param visitStart
	 * @param visitEnd
	 */
	public Visitor(int custNo, String name, int tel, String address, String nationality, Car car, int passportNo,
			Date visitStart, Date visitEnd) {
		super(custNo, name, tel, address, nationality, car);
		this.passportNo = passportNo;
		this.visitStart = visitStart;
		this.visitEnd = visitEnd;
	}
	
	


	public Visitor() {
		// TODO Auto-generated constructor stub
	}



	/**
	 * getPassportNo()
	 * 
	 * @return passportNo
	 */
	public int getPassportNo() {
		return passportNo;
	}

	/**
	 * 
	 * @param passportNo
	 */
	public void setPassportNo(int passportNo) {
		this.passportNo = passportNo;
	}

	/**
	 * getVisitStart()
	 * 
	 * @return visitStart
	 */
	public Date getVisitStart() {
		return visitStart;
	}

	/**
	 * 
	 * @param visitStart
	 */
	public void setVisitStart(Date secondDate3) {
		this.visitStart = secondDate3;
	}

	/**
	 * getVisitEnd()
	 * 
	 * @return visitEnd
	 */
	public Date getVisitEnd() {
		return visitEnd;
	}

	/**
	 * 
	 * @param visitEnd
	 */
	public void setVisitEnd(Date date1) {
		this.visitEnd = date1;
	}

	@Override
	public String toString() {
		return "Visitor [" + super.toString() + "passport No: " + passportNo + ", visit Start: " + visitStart
				+ ", visit End: " + visitEnd + "]";
	}

}
