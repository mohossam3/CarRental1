package customer;

import java.time.LocalDate;

import manager.RentDataManager;
import vehicle.Rental;
import vehicle.Vehicle;

/**
 * 
 * @project Car-Rental System - (Phase I)
 * @version 1.0
 * @class Payment
 * @author Mohamed Abdelmoety
 * @QUID 201703976
 */

public class Payment extends RentDataManager{
	private LocalDate payDate;
	private final int Deposit = 15000;
	private double totalAmountPaid;
	private int totalDepositPaid;
	private int totalDepositReturned;
	/**
	 * 
	 * @param payDate
	 * @param Deposit
	 * @param totalAmountPaid
	 * @param totalDepositPaid
	 * @param totalDepositReturned
	 */
	public Payment(LocalDate payDate, int totalAmountPaid, int totalDepositPaid, int totalDepositReturned) {
		super();
		this.payDate = payDate;
		this.totalAmountPaid = totalAmountPaid;
		this.totalDepositPaid = totalDepositPaid;
		this.totalDepositReturned = totalDepositReturned;
	}
	public Payment() {
		
	}

	/**
	 * getPayDate()
	 * 
	 * @return payDate
	 */
	public LocalDate getPayDate() {
		return payDate;
	}
	/**
	 * 
	 * @param payDate
	 */
	public void setPayDate(LocalDate payDate) {
		this.payDate = payDate;
	}
	/**
	 * getTotalAmountPaid()
	 * 
	 * @return totalAmountPaid
	 */
	public double getTotalAmountPaid() {
		return totalAmountPaid;
	}
	/**
	 * 
	 * @param totalAmountPaid2
	 */
	public void setTotalAmountPaid(double totalAmountPaid2) {
		this.totalAmountPaid = totalAmountPaid2;
	}
	/**
	 * getTotalDepositPaid()
	 * 
	 * @return totalDepositPaid
	 */
	public int getTotalDepositPaid() {
		return totalDepositPaid;
	}
	/**
	 * 
	 * @param totalDepositPaid
	 */
	public void setTotalDepositPaid(int totalDepositPaid) {
		this.totalDepositPaid = totalDepositPaid;
	}
	/**
	 * getTotalDepositReturned()
	 * 
	 * @return totalDepositReturned
	 */
	public int getTotalDepositReturned() {
		return totalDepositReturned;
	}
	/**
	 * getDeposit()
	 * 
	 * @return Deposit
	 */
	public int getDeposit() {
		return Deposit;
	}


/**
 * 
 * @param calctotalPayment.
 * @return calc.
 */
	public double calctotalPayment(Vehicle v ,Rental r) {
		//Vehicle v = new Vehicle();
		//Rental r = new Rental();
		//r1 = Rental.numberOfDays;
		
		double calc = v.getDailyRate()*r.getNumberOfDays() + getDeposit();
		
		return calc;
	}
	/**
	 * 
	 * @param calcRemainingDespoit.
	 * @return calcr.
	 */
	public double calcRemainingDespoit(Vehicle v,Rental e) {
		//Vehicle v = new Vehicle();
		//Rental e = new Rental();
		double r = v.getDailyRate();
		double d= e.getDamageDeduction();
		double l = e.setLatenessDeduction(r);
		
		double calcr = (e.calcDamageDeduction(d) + e.calcLatenessDeduction(l)) - (getDeposit());
		
		return calcr;
		
	}
	/**
	 * 
	 * @param issueReceipt.
	 * @return null.
	 */
	public String issueReceipt(double numberOfDamage, double l, Rental e,Vehicle v) {
		e.processReturn(numberOfDamage, l, v);
		 System.out.println("total of Payment"+ calctotalPayment(v, e));
		 System.out.println("RemainingDespoit" + calcRemainingDespoit(v,e));
		return "total of Payment: "+ calctotalPayment(v, e)+ " Remaining Despoit: " + calcRemainingDespoit(v,e);
		
	}
	

}
