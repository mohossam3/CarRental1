package customer;

import java.util.ArrayList;

import manager.RentDataManager;
import vehicle.Bus;
import vehicle.Car;
import vehicle.Vehicle;

public abstract class Customer {

	public int custNo;
	public String name;
	public int tel;
	public String address;
	public String nationality;
	public Car car;
	public Bus bus;


	public Customer() {
		
	}

	/**
	 * 
	 * @param custNo
	 * @param name
	 * @param tel
	 * @param address
	 * @param nationality
	 */


	public Customer(int custNo, String name, int tel, String address, String nationality, Car car, Bus bus) {
		super();
		this.custNo = custNo;
		this.name = name;
		this.tel = tel;
		this.address = address;
		this.nationality = nationality;
		this.car = car;
		this.bus = bus;
	}
	
	

	public Customer(int custNo, String name, int tel, String address, String nationality, Car car) {
		super();
		this.custNo = custNo;
		this.name = name;
		this.tel = tel;
		this.address = address;
		this.nationality = nationality;
		this.car = car;
	}

	/**
	 * getCustNo()
	 * 
	 * @return custNo
	 */
	
	
	
	public int getCustNo() {
		return custNo;
	}
	public Car getCar() {
		return car;
	}

	public void setCar(Car car) {
		this.car = car;
	}

	public Bus getBus() {
		return bus;
	}

	public void setBus(Bus bus) {
		this.bus = bus;
	}

	/**
	 * 
	 * @param custNo
	 */

	public void setCustNo(int custNo) {
		this.custNo = custNo;
	}
	/**
	 * getName()
	 * 
	 * @return name
	 */
	public String getName() {
		return name;
	}
	/**
	 * 
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * getTel()
	 * 
	 * @return tel
	 */
	public int getTel() {
		return tel;
	}
	/**
	 * 
	 * @param tel
	 */
	public void setTel(int tel) {
		this.tel = tel;
	}
	/**
	 * getAddress()
	 * 
	 * @return address
	 */
	public String getAddress() {
		return address;
	}
	/**
	 * 
	 * @param address
	 */
	public void setAddress(String address) {
		this.address = address;
	}
	/**
	 * getNationality()
	 * 
	 * @return nationality
	 */
	public String getNationality() {
		return nationality;
	}
	/**
	 * 
	 * @param nationality
	 */
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public void recordDetails() {
		getCustNo();
		getName();
		getAddress();
		getNationality();
		getTel();
			
	}
	/**
	 * @param custNo customer custNo to findCustomer
	 * @param customers ArrayList of customers
	 * @return	true if found, false if not found
	 */
	public boolean findCustomer(int custNo) {
		ArrayList<Customer>customers = new ArrayList<Customer>();
		for( Customer customer:customers) {
			if(customer.getCustNo() == custNo) {
				return true;
			}
		}

		return false;
	}
	/**
	* @return Customer
	 */

	@Override
	public String toString() {
		return "Cutomer Number: " + custNo + ", Cutomer Name: " + name + ", telephone: " + tel + ",Cutomer address: "
				+ address + ",Cutomer Nationality: " + nationality+ "]";
	}

	
	

}
