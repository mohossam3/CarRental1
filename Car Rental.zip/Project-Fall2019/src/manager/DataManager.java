package manager;
/**
 * @project Car-Rental System - (Phase I)
 * 
 * @version 3.0
 * @class DataManager to manage and handels all data.
 * @author Omar Teleb ----Created files and ArrayLists + 50% of Mthods and Display Menu ----
 * @QUID 201608748
 * @author Mohamed Abdelmoety ----Created 50% of Mthods and Display Menu ----
 * @QUID 201703976
 */

import java.nio.file.Files;
import java.io.BufferedReader;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Scanner;

import java.io.IOException;
import java.io.InputStreamReader;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import customer.Customer;
import customer.Payment;
import customer.Resident;
import customer.Visitor;
import vehicle.Bus;
import vehicle.Car;
import vehicle.Rental;
import vehicle.Vehicle;

public class DataManager {
//	public static ArrayList<Customer> allCustomers;
//	public static ArrayList<String> allRentals;
//	public static ArrayList<Vehicle> allVehicles;
	public static ArrayList<Resident> allResidents;
	public static ArrayList<Visitor> AllVisitors;
	public static ArrayList<Bus> allBuss;
	public static ArrayList<Car> AllCars;

	public DataManager() {

//		allCustomers = new ArrayList<Customer>();
		//allRentals = new ArrayList<String>();
//		allVehicles = new ArrayList<Vehicle>();
		allBuss = new ArrayList<Bus>();
		AllCars = new ArrayList<Car>();
		allResidents = new ArrayList<Resident>();
		AllVisitors = new ArrayList<Visitor>();
		readData();
	}

	private void readData() {
	//RentDataManager rdm = new RentDataManager();
		ReadResidents();
		// readCustomer();
		//readRental();
		readCars();
		readBuss();
		ReadVisitors();
		// readVehicle();
		// readBus();
		//rdm.readRent();
		//rdm.readRental();
	}

	private void ReadResidents() {

		String filePath = "allResidents.json";
		String CustomersData = "";
		Gson gson = new Gson();

		try {
			CustomersData = Files.readString(Paths.get(filePath));
			Resident[] readCustomersData = gson.fromJson(CustomersData, Resident[].class);
			Collections.addAll(allResidents, readCustomersData);

		} catch (Exception e) {

			System.out.println("Not Found: " + e.getMessage());
		}
		System.out.println(allResidents.size() + " Residents records found.");

	}

	private void ReadVisitors() {

		String filePath = "AllVisitors.json";
		String CustomersData = "";
		Gson gson = new Gson();

		try {
			CustomersData = Files.readString(Paths.get(filePath));
			Visitor[] readCustomersData = gson.fromJson(CustomersData, Visitor[].class);
			Collections.addAll(AllVisitors, readCustomersData);

		} catch (Exception e) {

			System.out.println("Not Found: " + e.getMessage());
		}
		System.out.println(AllVisitors.size() + " Visitor records found.");

	}

	

	private void readCars() {
		String filePath = "AllCars.json";
		String VehicleData = "";

		Gson gson = new Gson();
		try {
			VehicleData = Files.readString(Paths.get(filePath));
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		Car[] readVehicleData = gson.fromJson(VehicleData, Car[].class);

		Collections.addAll(AllCars, readVehicleData);

		System.out.println(AllCars.size() + " Vehicles records found.");
	}

	private void readBuss() {
		String filePath = "allBuss.json";
		String VehicleData = "";

		Gson gson = new Gson();
		try {
			VehicleData = Files.readString(Paths.get(filePath));
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		Bus[] readVehicleData = gson.fromJson(VehicleData, Bus[].class);

		Collections.addAll(allBuss, readVehicleData);

		System.out.println(allBuss.size() + " Vehicles records found.");
	}

	public void saveData() {
		saveResidents();
		saveVisitors();
	//	saveRental();
		//saveVehicle();
		 saveBuss();
		 saveCars();
	}

	public void saveResidents() {

		String filePath = "allResidents.json";
		Gson gson = new GsonBuilder().setPrettyPrinting().create();

		String jsonCustomer = gson.toJson(allResidents);
		try {
			Files.writeString(Paths.get(filePath), jsonCustomer);
		} catch (Exception e) {
			System.out.println("Not Saved");
		}
	}
	
	public void saveVisitors() {

		String filePath = "allVisitors.json";
		Gson gson = new GsonBuilder().setPrettyPrinting().create();

		String jsonCustomer = gson.toJson(AllVisitors);
		try {
			Files.writeString(Paths.get(filePath), jsonCustomer);
		} catch (Exception e) {
			System.out.println("Not Saved");
		}
	}

	public void saveCars() {
		String filePath = "AllCars.json";
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		String jsonVehicle = gson.toJson(AllCars);
		try {
			Files.writeString(Paths.get(filePath), jsonVehicle);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	public void saveBuss() {
		String filePath = "allBuss.json";
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		String jsonVehicle = gson.toJson(allBuss);
		try {
			Files.writeString(Paths.get(filePath), jsonVehicle);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public void addNewResisdent(Resident c) {
		ArrayList<Resident> c1 = new ArrayList<Resident>();
		if (!isDuplicateResNo(c.getCustNo())) {
			c1.add(c);
			allResidents.addAll(c1);
		} else
			System.out.println("Duplicate Customer Number.");

	}

	public void addNewVistor(Visitor c) {
		ArrayList<Visitor> cc = new ArrayList<Visitor>();
		if (!isDuplicatevisNo(c.getCustNo())) {
			cc.add(c);
			AllVisitors.addAll(cc);
		} else
			System.out.println("Duplicate Customer Number.");

	}

	public void addNewCar(Car c) {
		ArrayList<Car> cc = new ArrayList<Car>();
		if (!isDuplicateCarNo(c.getVechileNo())) {
			cc.add(c);
			AllCars.addAll(cc);

			// allVehicles.add(AllCars.toString());
			System.out.println(AllCars.toString() + "\n------------ Car Registered Succsseflly------------");
		} else
			System.out.println("Duplicate Car Number.");

	}

	public void addNewBus(Bus b) {
		ArrayList<Bus> bb = new ArrayList<Bus>();
		if (!isDuplicateBusNo(b.getVechileNo())) {
			bb.add(b);
			allBuss.addAll(bb);
			// allVehicles.add(allBuss.toString());
			System.out.println(allBuss.toString() + "\n------------ Bus Registered Succsseflly------------");
		} else
			System.out.println("Duplicate Bus Number.");

	}

	public Bus RentBuss(int b, int f) {

		// DataManager dm = new DataManager();
		@SuppressWarnings("unused")
		Resident s ;
		 s = (Resident) getResident(f);

		Vehicle v = new Bus();
		v.FindVehicle(b);

		for (int o = 0; o < allBuss.size(); o++) {

			int c1 = allBuss.get(o).getVechileNo();
			if (c1 == b & allBuss.get(o).isAvailable() != false) {
				v = allBuss.get(o);

				allBuss.get(o).setAvailable(false);
				System.out.println(v.toString() + "\n----rented Succssefully----");

			} else
				System.out.println("---Sorry htis Bus isn't Avilable for rent---");
		}

		return null;
	}
	
	
	
	
	public void RentCars(int n, int f) {

		// DataManager dm = new DataManager();

		for (int i = 0; i < allResidents.size(); i++) {

			int c = allResidents.get(i).getCustNo();
			if (c == f)
				;

		}
		Vehicle v = new Car();
		

		for (int o = 0; o < AllCars.size(); o++) {

			int c1 = AllCars.get(o).getVechileNo();
			if (c1 == n & AllCars.get(o).isAvailable() != false) {
				v = AllCars.get(o);

				AllCars.get(o).setAvailable(false);
				System.out.println(v.toString() + "\n----rented Succssefully----");

			} else
				System.out.println("---Sorry htis Car isn't Avilable---");
		}

	}

	public void ReturnVehicl() {

	}

	private boolean isDuplicateResNo(int custNo) {
		boolean duplicate = false;
		for (int i = 0; i < allResidents.size(); i++) {
			if (allResidents.get(i).getCustNo() == custNo) {
				duplicate = true;
				break;
			}
		}
		return duplicate;
	}
	private boolean isDuplicatevisNo(int custNo) {
		boolean duplicate = false;
		for (int i = 0; i < allResidents.size(); i++) {
			if (allResidents.get(i).getCustNo() == custNo) {
				duplicate = true;
				break;
			}
		}
		return duplicate;
	}

	public Resident getResident(int custNo) {
		Resident c = new Resident() ;
		for (int i = 0; i < allResidents.size(); i++)
			if (allResidents.get(i).getCustNo() == custNo) {
				c = allResidents.get(i);
				break;
			}

		return c;
	}
	public Visitor getVisitor(int custNo) {
		Visitor c = new Visitor();
		for (int i = 0; i < AllVisitors.size(); i++)
			if (AllVisitors.get(i).getCustNo() == custNo) {
				c = AllVisitors.get(i);
				break;
			}

		return c;
	}

	public Car getCar(int vehicleNO) {
		Car v = new Car();
		for (int i = 0; i < AllCars.size(); i++)

			if (AllCars.get(i).getVechileNo() == vehicleNO) {
				v = AllCars.get(i);
				break;
			}

		return v;
	}

	public Bus getBus(int vehicleNO) {
		Bus v = new Bus();
		for (int i = 0; i < allBuss.size(); i++)

			if (allBuss.get(i).getVechileNo() == vehicleNO) {
				v = allBuss.get(i);
				break;
			}

		return v;
	}

	private boolean isDuplicateCarNo(int vehicleNo) {
		boolean duplicate = false;
		for (int i = 0; i < AllCars.size(); i++) {
			if (AllCars.get(i).getVechileNo() == vehicleNo) {
				duplicate = true;
			}
		}
		return duplicate;
	}
	private boolean isDuplicateBusNo(int vehicleNo) {
		boolean duplicate = false;
		for (int i = 0; i < allBuss.size(); i++) {
			if (allBuss.get(i).getVechileNo() == vehicleNo) {
				duplicate = true;
			}
		}
		return duplicate;
	}

// ------------------------------------------------------------------------------------------------------------------
	/**
	 * RentProcess
	 * @throws ParseException 
	 * @throws IOException 
	 */
	public void RentProcess() throws IOException, ParseException {
		
		RentDataManager mrd = new RentDataManager();
		DataManager m = new DataManager();
		Rental r1 = new Rental();
		System.out.println("------Select an option------"+
						"\nEnter[1] to Rent for Resident"+
					    "\nEnter[2] to Rent for Visitor");
		Scanner ent = new Scanner(System.in);
		int in = ent.nextInt();
		switch (in) {
		case 1:
			System.out.println("----Rent for Resident----"+
								"\nFor Bus Enter [1]"+
								"\nFor Car Enter [2]"+
							   "\n-----------------------");
	Scanner g = new Scanner(System.in);
	int t = g.nextInt();
	// -----------------
	switch (t) {

	case 1:
		Bus v = new Bus();
		System.out.println("Enter Customer No: ");
		Scanner co = new Scanner(System.in);
		int n = co.nextInt();
		System.out.println(getResident(n).toString());;
		System.out.println("Enter a Bus Number:");
		Scanner no = new Scanner(System.in);
		int num = no.nextInt();
		getBus(num).setAvailable(false);;	
		v = getBus(num);
		v.setAvailable(true);
		System.out.println("Enter Damage Deduction:");
		Scanner d = new Scanner(System.in);
		double DamageDeduction = d.nextDouble();
		r1.setDamageDeduction(DamageDeduction);
		r1.getStartDate();
		LocalDate FirstDate = r1.getStartDate() ;
		System.out.println("Rent for How many days:");
		Scanner day = new Scanner(System.in);
		int days = day.nextInt();
		r1.setNumberOfDays(days);
		Payment pay =new Payment();
		pay.calctotalPayment(v, r1);
		RentDataManager drm = new RentDataManager();
		r1.setDateOFreturn(drm.dateAfter(FirstDate, days));
		r1.setPayment(pay);
		v.setRental(r1);
		getResident(n).setBus(v);
		saveResidents();
		m.saveData();
		// saveRental();
		System.out.println(m.toString());

		break;
	case 2:
		System.out.println("Enter Customer No: ");
		Scanner co2 = new Scanner(System.in);
		int n2 = co2.nextInt();

		System.out.println("Enter a Car Number:");
		Scanner no2 = new Scanner(System.in);
		int num2 = no2.nextInt();

		
			Car v3 = new Car();
			v3 = getCar(num2);
		double	rate = v3.getDailyRate();
			System.out.println(v3.toString());
			getCar(num2).setAvailable(false);
			r1.setLatenessDeduction(rate);
			r1.getLatenessDeduction();
			System.out.println("Damage Deduction:");
			Scanner d2 = new Scanner(System.in);
			double DamageDeduction2 = d2.nextDouble();
			r1.setDamageDeduction(DamageDeduction2);
			LocalDate StartDate = LocalDate.now();
			r1.setStartDate(StartDate);
			// LocalDate First =
			r1.getStartDate();
			System.out.println("Rent for How many Days:");
			Scanner d3 = new Scanner(System.in);
			int numberOfDays = d3.nextInt();
			Payment pay1 = new Payment();
			pay1.calctotalPayment(v3, r1);
			r1.setPayment(pay1);
			r1.setNumberOfDays(numberOfDays);
			r1.setDateOFreturn(mrd.dateAfter(StartDate, numberOfDays));
			r1.getLatenessDeduction();
			v3.setAvailable(true);
			v3.setRental(r1);
			getResident(n2).setCar(v3);
			saveResidents();
			// getCar(num2).setAvailable(false);

			m.saveData();
			System.out.println(getResident(n2).toString());
		
			
		
		} break;
		
		case 2:
			System.out.println("Rent Car: ");
	
		System.out.println("Enter Customer No: ");
		Scanner co2 = new Scanner(System.in);
		int n2 = co2.nextInt();

		System.out.println("Enter a Car Number:");
		Scanner no2 = new Scanner(System.in);
		int num2 = no2.nextInt();


		double	rate = getCar(num2).getDailyRate();
			Car v3 = new Car();
			v3 = getCar(num2);
			System.out.println(v3.toString());
			getCar(num2).setAvailable(false);
			r1.setLatenessDeduction(rate);
			r1.getLatenessDeduction();
			System.out.println("Damage Deduction:");
			@SuppressWarnings("resource")
			Scanner d2 = new Scanner(System.in);
			double DamageDeduction2 = d2.nextDouble();
			r1.setDamageDeduction(DamageDeduction2);
			LocalDate StartDate = LocalDate.now();
			r1.setStartDate(StartDate);
			// LocalDate First =
			r1.getStartDate();
			System.out.println("Rent for How many Days:");
			@SuppressWarnings("resource")
			Scanner d3 = new Scanner(System.in);
			int numberOfDays = d3.nextInt();
			Payment pay1 = new Payment();
			pay1.calctotalPayment(v3, r1);
			RentDataManager Mang = new RentDataManager();
			r1.setPayment(pay1);
			r1.setNumberOfDays(numberOfDays);
			r1.setDateOFreturn(Mang.dateAfter(StartDate, numberOfDays));
			r1.getLatenessDeduction();
			v3.setRental(r1);
			getResident(n2).setCar(v3);;
			saveResidents();


			m.saveData();
			System.out.println(getResident(n2).toString());
			Run();
		
			break;
		} 
	}
		
	
/**
 * ReturnProcess
 * @throws IOException
 */
public void	ReturnProcess() throws IOException {

	DataManager m = new DataManager();
	Rental r1 = new Rental();
	System.out.println("Enter[1]  for Resident"+
					 "\nEnter[2]  for Visitor");
	Scanner ent = new Scanner(System.in);
	int in = ent.nextInt();
	switch (in) {
	case 1:
		System.out.println("---Resident---");
		System.out.println("for Car Enter [1]"+
						 "\nfor Bus Enter [2]");
		Scanner tt = new Scanner(System.in);
		int rr = tt.nextInt();

		switch (rr) {
		case 1:
			
			System.out.println("Enter Customer number");
			Scanner sacn = new Scanner(System.in);
			int in1 = sacn.nextInt();
			getResident(in1);
			Resident re = new Resident();
			re = getResident(in1);
			System.out.println("Enter Car number");
			Scanner sacn1 = new Scanner(System.in);
			int in11 = sacn1.nextInt();
			Car vv = new Car();
			vv = getCar(in11);
		//	if(getResident(in1).getCar() == vv) {
			getCar(in11).setAvailable(true);
			saveCars();
			Rental Ret = new Rental();
			Ret = getResident(in1).getCar().getRental();
			final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd MM yyyy");
			System.out.println("Enter Return Date");
			final BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
			final String secondInput = reader.readLine();
			final LocalDate secondDate = LocalDate.parse(secondInput, formatter);
			Ret.setReturnDate(secondDate);
			
			System.out.println("number of Damage Deduction: ");
			@SuppressWarnings("resource")
			Scanner Damageno = new Scanner(System.in);
			double numberOfDamage = Damageno.nextInt();
			Ret.calcDamageDeduction(numberOfDamage);
			Ret.processReturn(numberOfDamage, getCar(in11).getDailyRate(), vv);
			Payment pay = new Payment();
			pay.calctotalPayment(vv, Ret);
			Ret.setPayment(pay);
			getResident(in1).getCar().setRental(Ret);
			saveResidents();
			saveData();
			//}
			// allRentals.get(j).calcDamageDeduction(numberOfDamage);
			// allRentals.get(j).calcLatenessDeduction(allVehicles.get(l).getDailyRate());
			// allRentals.clear();

			// m.ReturnVehicl();
			break;
			//}else
			//	System.out.println("Error [X]");
			//break;

		case 2:
			
			System.out.println("Enter Customer number");
			Scanner sacn111 = new Scanner(System.in);
			int in111 = sacn111.nextInt();

			System.out.println("Enter Bus number");
			Scanner sacn11 = new Scanner(System.in);
			int in22 = sacn11.nextInt();
			Vehicle vv1 = new Bus();
			vv1 = getBus(in22);

			getResident(in111);

			Rental Ret1 = new Rental();
			Ret1 = getResident(in111).getBus().getRental();
			final DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("dd MM yyyy");
			System.out.println("Enter Return Date");
			final BufferedReader reader1 = new BufferedReader(new InputStreamReader(System.in));
			final String secondInput1 = reader1.readLine();
			final LocalDate secondDate1 = LocalDate.parse(secondInput1, formatter1);
			Ret1.setReturnDate(secondDate1);
			
			System.out.println("number of Damage Deduction: ");
			@SuppressWarnings("resource")
			Scanner Damageno1 = new Scanner(System.in);
			double numberOfDamage1 = Damageno1.nextInt();
			Ret1.calcDamageDeduction(numberOfDamage1);
			Ret1.processReturn(numberOfDamage1, getBus(in22).getDailyRate(), vv1);
			Payment pay1 = new Payment();
			pay1.calctotalPayment(vv1, Ret1);
			Ret1.setPayment(pay1);
			getResident(in111).getBus().setRental(Ret1);
			saveResidents();
			saveData();
				 // ---------------[^ Not Wroking ^]------------------
				m.saveData();

			
			// allRentals.get(j).calcDamageDeduction(numberOfDamage);
			// allRentals.get(j).calcLatenessDeduction(allVehicles.get(l).getDailyRate());

			// m.ReturnVehicl();
			// save.add(m);

		} break;
		
	case 2:
		System.out.println("---Return Car---");
		System.out.println("Enter Customer number: ");
		Scanner sacn = new Scanner(System.in);
		int in1 = sacn.nextInt();
		getResident(in1);
		Resident re = new Resident();
		System.out.println("Enter Car number");
		Scanner sacn1 = new Scanner(System.in);
		int in11 = sacn1.nextInt();
		Vehicle vv = new Car();
		vv = getCar(in11);
		if(getVisitor(in1).getCar() == vv) {
		getCar(in11).setAvailable(true);
		saveCars();
		Rental Ret = new Rental();
		Ret = getVisitor(in1).getCar().getRental();
		final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd MM yyyy");
		System.out.println("Enter Return Date");
		final BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		final String secondInput = reader.readLine();
		final LocalDate secondDate = LocalDate.parse(secondInput, formatter);
		Ret.setReturnDate(secondDate);
		
		System.out.println("number of Damage Deduction: ");
		@SuppressWarnings("resource")
		Scanner Damageno = new Scanner(System.in);
		double numberOfDamage = Damageno.nextInt();
		Ret.calcDamageDeduction(numberOfDamage);
		Ret.processReturn(numberOfDamage, getCar(in11).getDailyRate(), vv);
		Payment pay = new Payment();
		pay.setPayDate(secondDate);
		System.out.println("Enter paid Amount: ");
		@SuppressWarnings("resource")
		Scanner paid = new Scanner(System.in);
		double totalAmountPaid = paid.nextInt();
		pay.setTotalAmountPaid(totalAmountPaid);
		
		pay.calcRemainingDespoit(vv, Ret);
		pay.issueReceipt(numberOfDamage, getCar(in11).getDailyRate(), Ret, vv);
		
		Ret.setPayment(pay);
		getVisitor(in1).getCar().setAvailable(false);
		getVisitor(in1).getCar().setRental(Ret);
		saveVisitors();
		saveData();
		}break;
		
	} 
	
	
}

//--------------------------------------------------------------------------------------------------------------------
/**
 * @Mthod Run -- Main Menu to Operate the Rental System.
 * @throws IOException
 * @throws ParseException
 *///---------------------------------------------------
	public void Run() throws IOException, ParseException {
		RentDataManager mrd = new RentDataManager();
		DataManager m = new DataManager();
		System.out.println(allResidents);
		System.out.println(AllCars);
	//	System.out.println(allRentals);

		// }

		int i = -1;
		do {

			Rental r1 = new Rental();
			@SuppressWarnings("resource")
			Scanner input1 = new Scanner(System.in);
			System.out.println("----------------------------------------");
			System.out.println("---------Vehicles Rental System---------");
			System.out.println("----------------------------------------");
			System.out.println("Enter [1] to rent"
					+ "\nEnter [2] to return"
					+ "\nEnter [3] to Add customer"
					+ "\nEnter [4] to Register new Vehicle" 
					+ "\nEnter [5] to Search for Vehicle"
					+ "\nEnter [6] to Search for Customer"
					+ "\nEnter [7] to Produce detailed tabular lists of all Vehicles and all Customers"
					+ "\nEnter [8] Produce detailed tabular lists of all rented vehicles names of Customers who rented"
					+ "\nEnter [9] to Show  all rented Vehicles" 
					+ "\nEnter [0] to Exit");
			System.out.println("----------------------------------------");
			i = input1.nextInt();
			
			switch (i) {

			case 1:
				/**
				 *  Rent Process:
				 */
				RentProcess();
				
				break;
			// ----------------------------------------------------------------------------------------

			case 2:{
					ReturnProcess();
			} break;
				 // -------------------------------------------------------------------------
				

			case 3:

				System.out.println("[1] to add risdent------ [2] to add vistor");
				Scanner costa = new Scanner(System.in);
				int p = costa.nextInt();
				switch (p) {
				case 1:
					//Resident resident = new Resident();
					// Scanner input3 = new Scanner(System.in);
					System.out.println("Enter Customer No: ");
					Scanner input6 = new Scanner(System.in);
					int n2 = input6.nextInt();
					int CustNo;
					if (isDuplicateResNo(n2) == true) {
						System.out.println("this Customer is Allredy add");
						break;
					} else


						CustNo =  n2;

					System.out.println("Enter Customer Name: ");
					Scanner input4 = new Scanner(System.in);
					String nn = input4.nextLine();
					
					String neame = nn;
					
					System.out.println("Enter Customer address: ");
					Scanner input5 = new Scanner(System.in);
					String n1 = input5.nextLine();
					
					String Address = n1;
					
					System.out.println("Enter Customer Nationality: ");
					Scanner input7 = new Scanner(System.in);
					String n3 = input7.nextLine();
					
					String Nationality =n3;
					
					System.out.println("Enter Customer Tel: ");
					Scanner input8 = new Scanner(System.in);
					int n4 = input8.nextInt();
					
					int Tel = n4;
					
					System.out.println("Enter Id Card Number:");
					Scanner id = new Scanner(System.in);
					int idCard = id.nextInt();
					
					
					
					System.out.println("Enter bank Name:");
					Scanner bank = new Scanner(System.in);
					String bankName = bank.nextLine();
					
					Resident resident = new Resident(CustNo, neame, Tel, Address, Nationality, null, null, idCard, bankName);
					
					addNewResisdent(resident);
					m.saveData();
					// saveCustomer();
					// save.add(m);
					System.out.println("Resident Customer has been added Successfully");
					System.out.println(resident.toString());

					break;

				case 2:
					

					System.out.println("Enter Customer No: ");
					Scanner inp6 = new Scanner(System.in);
					int n21 = inp6.nextInt();

					Scanner inp = new Scanner(System.in);
					System.out.println("Enter Customer Name: ");
					Scanner inp1 = new Scanner(System.in);
					String nn1 = inp1.nextLine();

					System.out.println("Enter Customer address: ");
					Scanner inp2 = new Scanner(System.in);
					String n12 = inp2.nextLine();

					System.out.println("Enter Customer Nationality: ");
					Scanner inp7 = new Scanner(System.in);
					String n31 = inp7.nextLine();

					System.out.println("Enter Customer Tel: ");
					Scanner inp8 = new Scanner(System.in);
					int n41 = inp8.nextInt();
					

					System.out.println("Enter Passport Number:");
					Scanner Passport = new Scanner(System.in);
					int PassportNo = Passport.nextInt();
					

					System.out.println("Enter Start Date of vist");
					SimpleDateFormat dates = new SimpleDateFormat("MM/dd/yyyy");
					BufferedReader reader3 = new BufferedReader(new InputStreamReader(System.in));
					System.out.println("Enter the Date of rturn as --> MM/dd/yyyy:");
					String secondInput3 = reader3.readLine();
					Date secondDate3 = dates.parse(secondInput3);
					

					System.out.println("Enter End Date of vist");
					SimpleDateFormat dates1 = new SimpleDateFormat("MM/dd/yyyy");
					BufferedReader reader4 = new BufferedReader(new InputStreamReader(System.in));
					System.out.println("Enter the Date of rturn as --> MM/dd/yyyy:");
					String secondInput4 = reader4.readLine();
					Date date1 = dates1.parse(secondInput4);
					
					Visitor vistor = new Visitor(n21, nn1, n41, n12, n31, null, PassportNo, secondDate3, date1);
					m.addNewVistor(vistor);
					m.saveData();

					System.out.println("Vistor Customer has been added Successfully");
					System.out.println(vistor.toString());
					break;

				} // ---------------------------------------------------------------------------------

				break;
			case 4:
				System.out.println("for Bus Enter 1 -- For Car Enter 2");

				Scanner s = new Scanner(System.in);
				int y = s.nextInt();

				switch (y) {
				case 1:
					Bus h = new Bus();
					System.out.println("-----Adding new Bus-----");
					System.out.println("Enter Bus Number:");
					Scanner u = new Scanner(System.in);
					int u1 = u.nextInt();
					h.setVechileNo(u1);
					System.out.println("Enter Bus make:");
					Scanner s1 = new Scanner(System.in);
					String y1 = s1.nextLine();
					h.setMake(y1);
					System.out.println("Enter Vehicle Brand:");
					Scanner s2 = new Scanner(System.in);
					String y2 = s2.nextLine();
					h.setBrand(y2);
					System.out.println("Enter Vehicle model:");
					Scanner s3 = new Scanner(System.in);
					String y3 = s3.nextLine();
					h.setModel(y3);
					System.out.println("Enter Vehicle year of model:");
					Scanner s4 = new Scanner(System.in);
					int y4 = s4.nextInt();
					h.setModelYear(y4);
					System.out.println("Enter Vehicle Daily Rate:");
					Scanner s5 = new Scanner(System.in);
					double y5 = s5.nextDouble();
					h.setDailyRate(y5);
					System.out.println("Enter Number of seat:");
					Scanner s14 = new Scanner(System.in);
					int y14 = s14.nextInt();
					h.setNumberOfSeats(y14);
					h.setAvailable(true);
					m.addNewBus(h);
					// m.saveVehicle();
					m.saveData();
					break;

				case 2: // ----------------------------------
					Car l = new Car();
					System.out.println("-----Adding new Car-----");
					System.out.println("Enter Vehicle Number:");
					Scanner s6 = new Scanner(System.in);
					int y6 = s6.nextInt();
					l.setVechileNo(y6);
					System.out.println("Enter Vehicle make:");
					Scanner s7 = new Scanner(System.in);
					String y7 = s7.nextLine();
					l.setMake(y7);
					System.out.println("Enter Vehicle Brand:");
					Scanner s8 = new Scanner(System.in);
					String y8 = s8.nextLine();
					l.setBrand(y8);
					System.out.println("Enter Vehicle model:");
					Scanner s9 = new Scanner(System.in);
					String y9 = s9.nextLine();
					l.setModel(y9);
					System.out.println("Enter Vehicle year of model:");
					Scanner s10 = new Scanner(System.in);
					int y10 = s10.nextInt();
					l.setModelYear(y10);
					System.out.println("Enter Vehicle Daily Rate:");
					Scanner s11 = new Scanner(System.in);
					double y11 = s11.nextDouble();
					l.setDailyRate(y11);
					System.out.println("body Type:");
					Scanner s12 = new Scanner(System.in);
					String y12 = s12.nextLine();
					l.setBodyType(y12);
					System.out.println("gear Type:");
					Scanner s13 = new Scanner(System.in);
					String y13 = s13.nextLine();
					l.setGearType(y13);
					System.out.println("Engin size:");
					Scanner s15 = new Scanner(System.in);
					int y15 = s15.nextInt();
					l.setEngineSize(y15);
					l.setAvailable(true);
					m.addNewCar(l);
					// m.saveVehicle();
					m.saveData();
					break;
				}break;
			case 5:
				System.out.println("Enter Vehicle Number:");
				Scanner r = new Scanner(System.in);
				int a = r.nextInt();
				if(getCar(a) != null)
				System.out.println(getCar(a).toString());
				else
					System.out.println(getBus(a).toString());
				break;
			case 6:
				System.out.println("Enter Customer Number:");
				Scanner c = new Scanner(System.in);
				int n= c.nextInt();
				if(getResident(n) != null) {
					System.out.println(getResident(n));
				}else
					System.out.println(getVisitor(n));
				
				break;

			//case 7:
			//case 8:
			
				// ----------------------------------------------------------------
			}
		} while (i != 0);

		System.exit(i);

	}
}
