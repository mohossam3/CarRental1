package manager;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import customer.Customer;
import customer.Payment;
import vehicle.Car;
import vehicle.Rental;
import vehicle.Vehicle;

/**
 * @project Car-Rental System - (Phase I)
 * @version 2.0
 * @class RentDataManager ---Handels Rents an returns oprations.---
 * @author Omar Teleb
 * @QUID 201608748
 */
public class RentDataManager {
	public static ArrayList<RentDataManager> Rent;
	public static ArrayList<String> allRentals;
	public Rental rental;
	public Customer customer;
	public Vehicle vehicle;
	
	

	public RentDataManager(Rental rental, Customer customer, Vehicle vehicle) {
		super();
		this.rental = rental;
		this.customer = customer;
		this.vehicle = vehicle;
	}

	public RentDataManager() {
		Rent = new ArrayList<RentDataManager>();
		allRentals = new ArrayList<String>();
//	readRent();
	}

	/**
	 * 
	 * @return
	 */
	
	

	public static ArrayList<RentDataManager> getRent() {
		return Rent;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Vehicle getVehicle() {
		return vehicle;
	}

	public void setVehicle(Vehicle vehicle) {
		this.vehicle = vehicle;
	}

	/**
	 * 
	 * @param rent
	 */

	public static void setRent(ArrayList<RentDataManager> rent) {
		Rent = rent;
	}

	/**
	 * 
	 * @return
	 */

	public static ArrayList<String> getAllRentals() {
		return allRentals;
	}

	/**
	 * 
	 * @param allRentals
	 */

	public static void setAllRentals(ArrayList<String> allRentals) {
		RentDataManager.allRentals = allRentals;
	}

	/**
	 * 
	 * @return
	 */

	public Rental getRental() {
		return rental;
	}

	/**
	 * getRental()
	 * 
	 * @param rental
	 */

	public void setRental(Rental rental) {
		this.rental = rental;
	}

	/**
	 * readRent() to load the file "Rents.json" and reads data.
	 */

	public void readRent() {
		String filePath = "Rents.json";
		String RentsData = "";
		Gson gson = new Gson();

		try {
			RentsData = Files.readString(Paths.get(filePath));
			RentDataManager[] readRentsData = gson.fromJson(RentsData, RentDataManager[].class);
			Collections.addAll(Rent, readRentsData);

		} catch (Exception e) {

			System.out.println("Not Found: " + e.getMessage());
		}
		// System.out.println(Rent.size() + " Rent records found.");
	}

	/**
	 * saveRent() save all rented data to file Rents.json"
	 */

	public static void saveRent() {
		String filePath = "Rents.json";
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		String jsonRental = gson.toJson(Rent);
		try {

			Files.writeString(Paths.get(filePath), jsonRental);
		} catch (Exception e) {
			System.out.println("Not Saved");
		}
	}

	/**
	 * 
	 */

	public static void saveRental() {
		String filePath = "allRentals.json";
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		String jsonRental = gson.toJson(allRentals);
		try {

			Files.writeString(Paths.get(filePath), jsonRental);
		} catch (Exception e) {
			System.out.println("Not Saved");
		}
		/**
		 * 
		 */
	}

	public void readRental() {
		String filePath = "allRentals.json";
		String CustomersData = "";
		Gson gson = new Gson();

		try {
			CustomersData = Files.readString(Paths.get(filePath));
			String[] readCustomersData = gson.fromJson(CustomersData, String[].class);
			Collections.addAll(allRentals, readCustomersData);

		} catch (Exception e) {

			System.out.println("Not Found: " + e.getMessage());
		}
		// System.out.println(allRentals.size() + " Rental records found.");
	}

	/**
	 * 
	 * @param FirstDate
	 * @param d
	 * @return
	 */

	public LocalDate dateAfter(LocalDate FirstDate, int d) {
		LocalDate lastDate = FirstDate.plusDays(d);
		return lastDate;
	}

	/**
	 * @Method Rent to Operate renting process;
	 * @param c to set Customer
	 * @param v to set Vehicle
	 * @param r to set Rental
	 */

	public void Rent(Customer c, Vehicle v, Rental r) {
		ArrayList<RentDataManager> m = new ArrayList<RentDataManager>();
		RentDataManager mdr = new RentDataManager();
		mdr.setCustomer(c);
		mdr.setVehicle(v);
		mdr.setRental(r);
		m.add(mdr);
		Rent.addAll(m);
		saveRent();
	}

	/**
	 * @Mthod Rturn to operate Rturn process
	 * @param CustNo to set Customer number
	 * @param VehNo  to set Vehicle number
	 * @throws IOException Exception
	 */
	public static void Rturn(Customer CustNo, Vehicle VehNo) throws IOException {

		ArrayList<String> print = new ArrayList<String>();
		Rental r = new Rental();
		DataManager m = new DataManager();

		final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd MM yyyy");
		System.out.println("Enter Return Date");
		final BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		final String secondInput = reader.readLine();
		final LocalDate secondDate = LocalDate.parse(secondInput, formatter);

		System.out.println("number of Damage Deduction: ");
		@SuppressWarnings("resource")
		Scanner Damageno = new Scanner(System.in);
		double numberOfDamage = Damageno.nextInt();

		int no = VehNo.getVechileNo();

		Payment pay = new Payment();
		RentDataManager mr = new RentDataManager();
		for (int i = 0; i < Rent.size(); i++) {
			if (Rent.get(i).equals(CustNo)) {
			
				r = Rent.get(i).getRental();
				mr.setRental(r);
				
				}
			
			break;
		}
		mr.getRental();
		r.setReturnDate(secondDate);
		//r.setNumberOfDays(mr.getRental().getNumberOfDays());
		//VehNo.getRental().getDamageDeduction();
		r.getDamageDeduction();
		r.setLatenessDeduction(m.getCar(no).getDailyRate());
		r.calcDamageDeduction(numberOfDamage);
		r.calcLatenessDeduction(m.getCar(no).getDailyRate());
		r.calaOverdueDays();
		mr.setRental(r);
		pay.issueReceipt(numberOfDamage, m.getCar(no).getDailyRate(), r, VehNo);
		print.add(CustNo.toString());
		print.add(VehNo.toString());
		print.add(mr.getRental().toString());
		print.add(pay.issueReceipt(numberOfDamage, m.getCar(no).getDailyRate(), r, VehNo));
		allRentals.addAll(print);
		saveRental();
		for (int i = 0; i < Rent.size(); i++) {
			if (Rent.get(i).equals(CustNo)) {
				Rent.remove(VehNo);
				Rent.remove(r);
				}break;
		} 
		saveRent();
	}
}
