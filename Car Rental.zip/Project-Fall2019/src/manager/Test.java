package manager;

import manager.DataManager;
import java.io.IOException;
import java.text.ParseException;

/**
 * @project Car-Rental System - (Phase I)
 * @version 2.0
 * @class Test ---main.---
 * @author Omar Teleb
 * @QUID 201608748
 */
public class Test {
	public static void main(String[] args) throws IOException, ParseException {
		// TODO Auto-generated method stub
/**
 * @Opjcet D of type DataManager to Excute Run() Method.
 */
		DataManager D = new DataManager();
		
		D.Run();
}
}
